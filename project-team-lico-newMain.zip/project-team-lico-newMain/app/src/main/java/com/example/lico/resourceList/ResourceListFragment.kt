package com.example.lico.resourceList

annotation class ResourceListFragment()
